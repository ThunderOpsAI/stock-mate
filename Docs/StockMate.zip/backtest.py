"""
Backtesting utility - Validate the bot's historical accuracy
Tests: Did stocks that scored high actually outperform?
"""

import pandas as pd
import numpy as np
import yfinance as yf
import logging
from datetime import datetime, timedelta
from stock_bot_main import StockAnalysisBot, FeatureEngineer

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class StockBotBacktester:
    """Validates bot performance on historical data"""
    
    def __init__(self):
        self.bot = StockAnalysisBot()
        self.engineer = FeatureEngineer()
    
    def backtest_period(self, tickers, test_date, lookahead_days=30):
        """
        Simulate the bot's picks on a specific date
        Return: accuracy, precision, returns of top picks
        """
        logger.info(f"Backtesting picks from {test_date} with {lookahead_days}-day horizon...")
        
        results = []
        
        for ticker in tickers:
            try:
                # Get data up to test_date
                stock = yf.Ticker(ticker)
                hist = stock.history(start='2020-01-01', end=test_date)
                
                if len(hist) < 100:
                    continue
                
                # Score the stock as of test_date
                features = self.engineer.calculate_technical_features(hist)
                latest_features = features.iloc[-1:]
                
                if latest_features.isna().any().any():
                    continue
                
                # Load model if not loaded
                if self.bot.model is None:
                    self.bot.load_model()
                
                # Get prediction
                X_scaled = self.bot.scaler.transform(latest_features[self.bot.feature_cols])
                prob = self.bot.model.predict_proba(X_scaled)[0][1]
                
                # Get actual returns lookahead_days after test_date
                future_data = stock.history(start=test_date, end=test_date + timedelta(days=lookahead_days + 10))
                
                if len(future_data) == 0:
                    continue
                
                # Calculate actual return
                price_at_test = hist['Close'].iloc[-1]
                future_price = future_data['Close'].iloc[min(lookahead_days, len(future_data)-1)]
                actual_return = (future_price - price_at_test) / price_at_test
                
                results.append({
                    'ticker': ticker,
                    'prediction_score': prob,
                    'actual_return': actual_return,
                    'outperformed': actual_return > 0.05  # 5% target
                })
            
            except Exception as e:
                logger.debug(f"Error backtesting {ticker}: {e}")
                continue
        
        return pd.DataFrame(results)
    
    def analyze_backtest_results(self, results_df):
        """Analyze backtest results"""
        if len(results_df) == 0:
            logger.warning("No backtest results")
            return
        
        # Split into high-confidence and low-confidence picks
        high_confidence = results_df[results_df['prediction_score'] > 0.6]
        low_confidence = results_df[results_df['prediction_score'] <= 0.6]
        
        logger.info("\n" + "="*60)
        logger.info("BACKTEST RESULTS")
        logger.info("="*60)
        
        logger.info(f"\nTotal Predictions: {len(results_df)}")
        logger.info(f"High Confidence (>0.6): {len(high_confidence)}")
        logger.info(f"Low Confidence (<=0.6): {len(low_confidence)}")
        
        if len(high_confidence) > 0:
            high_accuracy = (high_confidence['outperformed'].sum() / len(high_confidence))
            high_avg_return = high_confidence['actual_return'].mean()
            logger.info(f"\nHigh Confidence Performance:")
            logger.info(f"  Accuracy: {high_accuracy:.1%} hit target (>5% in 30 days)")
            logger.info(f"  Avg Return: {high_avg_return:.2%}")
            logger.info(f"  Best Pick: {high_confidence.nlargest(1, 'actual_return')['actual_return'].values[0]:.2%}")
            logger.info(f"  Worst Pick: {high_confidence.nsmallest(1, 'actual_return')['actual_return'].values[0]:.2%}")
        
        if len(low_confidence) > 0:
            low_accuracy = (low_confidence['outperformed'].sum() / len(low_confidence))
            low_avg_return = low_confidence['actual_return'].mean()
            logger.info(f"\nLow Confidence Performance:")
            logger.info(f"  Accuracy: {low_accuracy:.1%}")
            logger.info(f"  Avg Return: {low_avg_return:.2%}")
        
        overall_accuracy = (results_df['outperformed'].sum() / len(results_df))
        logger.info(f"\nOverall Accuracy: {overall_accuracy:.1%}")
        logger.info(f"Average Return (All Picks): {results_df['actual_return'].mean():.2%}")
        
        # Correlation between score and actual return
        correlation = results_df['prediction_score'].corr(results_df['actual_return'])
        logger.info(f"Score-to-Return Correlation: {correlation:.3f}")
        logger.info("(Higher = model is well-calibrated)")
        
        logger.info("="*60 + "\n")
        
        return {
            'total': len(results_df),
            'accuracy': overall_accuracy,
            'high_confidence_accuracy': high_accuracy if len(high_confidence) > 0 else 0,
            'avg_return': results_df['actual_return'].mean(),
            'correlation': correlation
        }


def main():
    """Run backtest on historical data"""
    backtester = StockBotBacktester()
    
    # Load model
    backtester.bot.load_model()
    
    # Get some tickers to test
    tickers = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'TSLA', 'META', 'NFLX', 'JPM', 'WMT']
    
    # Backtest from 30 days ago
    test_date = (datetime.now() - timedelta(days=60)).strftime('%Y-%m-%d')
    
    logger.info(f"Running backtest on {len(tickers)} stocks as of {test_date}...")
    results = backtester.backtest_period(tickers, test_date, lookahead_days=30)
    
    # Analyze
    backtester.analyze_backtest_results(results)
    
    # Save detailed results
    results.to_csv('backtest_results.csv', index=False)
    logger.info("Detailed results saved to backtest_results.csv")


if __name__ == '__main__':
    main()
