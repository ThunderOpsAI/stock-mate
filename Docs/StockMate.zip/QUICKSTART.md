# Stock Analysis Bot - QUICKSTART (5 Minutes)

## What You Just Got

A complete, free, machine-learning-powered stock screening bot that finds undervalued stocks daily.

## Before You Start
Make sure you have Python 3.8+ installed:
```bash
python --version
```

## Installation & First Run (4 Commands)

### 1. Install Python Dependencies
```bash
pip install -r requirements.txt
```
This installs: pandas, numpy, yfinance, scikit-learn

### 2. Run the Bot
```bash
python stock_bot_main.py
```

**First run will take 20-30 minutes** (training the ML model on 2 years of data)
Subsequent runs take 5-10 minutes.

### 3. Check the Results
When done, you'll have:
- `report_YYYYMMDD_HHMMSS.txt` ← **Read this first!**
- `stock_picks_YYYYMMDD_HHMMSS.csv` ← Open in Excel/Google Sheets
- `stock_bot.log` ← Detailed execution log

### 4. Automate It (Optional)

**Mac/Linux - Run Daily at 5 AM:**
```bash
crontab -e
# Add this line:
0 5 * * 1-5 cd /path/to/stock_bot && python stock_bot_main.py
```

**Windows - Use Task Scheduler:**
1. Open Task Scheduler
2. Create Basic Task
3. Set trigger: Daily, 5:00 AM
4. Set action: `python.exe C:\path\to\stock_bot_main.py`

## Understanding the Output

### Report Format:
```
AAPL | Score: 0.75
  ML Score: 0.78 | Fundamental: 0.71
  Current Price: $185.50
  P/E Ratio: 28.1
  RSI: 34 | MACD Signal: 0.025
```

**What it means:**
- **Score 0.75**: Strong buy signal (0-1 scale, higher is better)
- **ML Score**: ML model's confidence it will return >5% in 30 days
- **Fundamental**: How healthy the company is (P/E, debt, ROE, etc.)
- **RSI 34**: Oversold = potential good entry point
- **Price to SMA50**: 0.97 = trading below 50-day average

### CSV File:
- Open in Excel or Google Sheets
- Sort by `combined_score` (descending) for best opportunities
- Export to share with others

## Customization (5 Minutes)

Edit `config.py` to change:

```python
NUM_STOCKS_TO_TRAIN = 100        # How many stocks to analyze
NUM_STOCKS_TO_SCREEN = 100       # Increase for broader analysis
TOP_N_PICKS = 20                 # How many top picks to report
ML_TARGET_RETURN = 0.05          # 5% = target is 5% return in 30 days
ML_LOOKAHEAD_DAYS = 30           # Predict next 30 days
```

Then re-run: `python stock_bot_main.py`

## Scaling Up

### Want to analyze more stocks?
In `stock_bot_main.py`, line ~94:
```python
return tickers  # Remove the [:100] to get all 500+ S&P 500 stocks
```

### Want weekly instead of daily?
Edit crontab/Task Scheduler trigger to run weekly instead of daily.

### Want to integrate with a broker?
See Advanced Setup section in README.md

## Troubleshooting

**"Error: Not enough data for ticker X"**
- Normal. Bot skips stocks with insufficient history.

**"ModuleNotFoundError: No module named 'yfinance'"**
- Run: `pip install -r requirements.txt`

**"Script is very slow"**
- First run trains model (takes 20-30 min)
- If subsequent runs are slow, reduce `NUM_STOCKS_TO_SCREEN` in config.py

**"I don't trust the picks"**
- Backtest it: `python backtest.py`
- This shows historical accuracy on past recommendations

## Next Steps

- [ ] Install dependencies: `pip install -r requirements.txt`
- [ ] Run bot once: `python stock_bot_main.py`
- [ ] Read the report: Open `report_*.txt`
- [ ] Review results: Open `stock_picks_*.csv`
- [ ] Set up automation: Add to cron or Task Scheduler
- [ ] Backtest: `python backtest.py` (optional, validates accuracy)
- [ ] Expand: Change config.py to analyze more stocks
- [ ] Monitor: Check reports daily/weekly

## What Makes This Different?

✅ **Uses Machine Learning** - Predicts which stocks will outperform
✅ **Free Data Sources** - Yahoo Finance (no API keys, no costs)
✅ **Minimal Maintenance** - Run once to train, then daily screening takes 5-10 min
✅ **Scales to Commercial** - Can expand from 100 to 1000+ stocks
✅ **Transparent** - All code is open, you control everything
✅ **Combines ML + Fundamentals** - Not just technical analysis

## Important Disclaimer

⚠️ **This is educational only. NOT investment advice.**

- Past performance doesn't guarantee future results
- Always do your own due diligence
- Markets are unpredictable
- Use at your own risk

---

**You're all set!** Run `python stock_bot_main.py` and find some deals! 📈

Questions? Check README.md for detailed documentation.
