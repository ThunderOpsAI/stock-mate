"""
Configuration file - Customize bot behavior here
"""

# Data settings
DATA_LOOKBACK_PERIOD = '2y'  # How much historical data to use for training
NUM_STOCKS_TO_TRAIN = 100  # Number of stocks to train on (increase for more data, slower training)
NUM_STOCKS_TO_SCREEN = 100  # Number of stocks to screen each run

# ML Model settings
ML_MODEL_TYPE = 'RandomForest'  # Algorithm: RandomForest, GradientBoosting, etc.
ML_TARGET_RETURN = 0.05  # 5% = target is 5% return in 30 days
ML_LOOKAHEAD_DAYS = 30  # Predict returns over next 30 days
ML_TEST_SPLIT = 0.2  # 80% train, 20% test
ML_RANDOM_STATE = 42  # For reproducibility

# Random Forest hyperparameters (if using RF)
RF_N_ESTIMATORS = 100  # Number of trees
RF_MAX_DEPTH = 15  # Maximum tree depth
RF_MIN_SAMPLES_SPLIT = 10  # Minimum samples to split a node
RF_MIN_SAMPLES_LEAF = 5  # Minimum samples in leaf
RF_CLASS_WEIGHT = 'balanced'  # Handle class imbalance

# Output settings
TOP_N_PICKS = 20  # How many top picks to report
SAVE_REPORT_TO_FILE = True
SAVE_CSV_TO_FILE = True
SAVE_LOG_TO_FILE = True

# Scoring weights
ML_SCORE_WEIGHT = 0.6  # 60% weight to ML model
FUNDAMENTAL_SCORE_WEIGHT = 0.4  # 40% weight to fundamentals

# Fundamental thresholds (for scoring)
IDEAL_PE_MIN = 10
IDEAL_PE_MAX = 20
IDEAL_PB_MAX = 3
MIN_ROE_THRESHOLD = 0.15
MAX_DEBT_TO_EQUITY = 2.0

# Features to use
INCLUDE_TECHNICAL = True
INCLUDE_FUNDAMENTALS = True
INCLUDE_VOLUME = True

# Data sources
USE_YAHOO_FINANCE = True
FETCH_FUNDAMENTALS = True

# API settings
YFINANCE_PROGRESS = False  # Show download progress bar

# Logging
LOG_LEVEL = 'INFO'  # DEBUG, INFO, WARNING, ERROR
LOG_TO_CONSOLE = True
LOG_TO_FILE = True
LOG_FILE = 'stock_bot.log'

# Feature engineering
TECHNICAL_PERIODS = {
    'sma_short': 20,
    'sma_medium': 50,
    'sma_long': 200,
    'rsi_period': 14,
    'macd_fast': 12,
    'macd_slow': 26,
    'macd_signal': 9,
    'bollinger_period': 20,
    'bollinger_std': 2,
    'volume_ma_period': 20
}

# Screening filters (optional - used to pre-filter stocks)
MIN_PRICE = 5  # Minimum stock price
MAX_PRICE = 500  # Maximum stock price
MIN_VOLUME = 1000000  # Minimum daily volume
MIN_MARKET_CAP = 1e9  # Minimum market cap ($1B)

# Email settings (for automated reporting)
SEND_EMAIL_REPORT = False
EMAIL_SENDER = 'your_email@gmail.com'
EMAIL_RECIPIENT = 'your_email@gmail.com'
EMAIL_SMTP_SERVER = 'smtp.gmail.com'
EMAIL_SMTP_PORT = 465

# Scheduler settings (for automation)
SCHEDULE_ENABLED = False
SCHEDULE_TIME = '05:00'  # 5 AM (before market open)
SCHEDULE_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']  # Weekdays only

# Advanced settings
CACHE_DATA = True  # Cache downloaded data
CACHE_DIR = 'data_cache'
MODEL_PATH = 'stock_model.pkl'
SCALER_PATH = 'scaler.pkl'
BACKTEST_ENABLED = False
BACKTEST_START_DATE = '2023-01-01'

# Feature selection
FEATURE_SELECTION = False  # Use feature importance to reduce features
TOP_FEATURES = 15  # If feature selection enabled, use top N features

# Class weights (to handle imbalanced data)
HANDLE_CLASS_IMBALANCE = True
POS_CLASS_WEIGHT = 1.5  # Weight for positive class (good buys)
NEG_CLASS_WEIGHT = 0.5  # Weight for negative class

print("Config loaded successfully")
