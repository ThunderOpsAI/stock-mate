"""
Stock Analysis Bot - Market-wide screening for good buy opportunities
Uses free APIs (Yahoo Finance, Alpha Vantage) and ML to identify undervalued stocks
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import yfinance as yf
import pickle
import os
import logging
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('stock_bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class StockDataFetcher:
    """Handles all data retrieval from free sources"""
    
    def __init__(self):
        self.cache_dir = 'data_cache'
        os.makedirs(self.cache_dir, exist_ok=True)
    
    def get_sp500_tickers(self):
        """Get S&P 500 tickers from yfinance"""
        logger.info("Fetching S&P 500 tickers...")
        try:
            sp500 = pd.read_html('https://en.wikipedia.org/wiki/List_of_S%26P_500_companies')[0]
            tickers = sp500['Symbol'].tolist()
            logger.info(f"Retrieved {len(tickers)} S&P 500 tickers")
            return tickers[:100]  # Start with top 100 for speed during development
        except Exception as e:
            logger.error(f"Error fetching S&P 500 tickers: {e}")
            return []
    
    def fetch_stock_data(self, ticker, period='2y'):
        """Fetch historical OHLCV data"""
        try:
            data = yf.download(ticker, period=period, progress=False)
            if data.empty:
                return None
            return data
        except Exception as e:
            logger.debug(f"Error fetching data for {ticker}: {e}")
            return None
    
    def fetch_stock_info(self, ticker):
        """Fetch company fundamentals"""
        try:
            stock = yf.Ticker(ticker)
            info = stock.info
            
            return {
                'ticker': ticker,
                'pe_ratio': info.get('trailingPE', np.nan),
                'pb_ratio': info.get('priceToBook', np.nan),
                'dividend_yield': info.get('dividendYield', 0),
                'debt_to_equity': info.get('debtToEquity', np.nan),
                'current_ratio': info.get('currentRatio', np.nan),
                'roe': info.get('returnOnEquity', np.nan),
                'market_cap': info.get('marketCap', np.nan),
                'fifty_two_week_high': info.get('fiftyTwoWeekHigh', np.nan),
                'fifty_two_week_low': info.get('fiftyTwoWeekLow', np.nan),
                'revenue_growth': info.get('revenueGrowth', np.nan),
                'earnings_growth': info.get('earningsGrowth', np.nan),
                'current_price': info.get('currentPrice', np.nan),
            }
        except Exception as e:
            logger.debug(f"Error fetching info for {ticker}: {e}")
            return None

class FeatureEngineer:
    """Creates technical and fundamental features for ML model"""
    
    @staticmethod
    def calculate_technical_features(df):
        """Calculate technical indicators from price data"""
        features = pd.DataFrame(index=df.index)
        
        # Price momentum
        features['returns'] = df['Close'].pct_change()
        features['log_returns'] = np.log(df['Close'] / df['Close'].shift(1))
        
        # Moving averages
        features['sma_20'] = df['Close'].rolling(window=20).mean()
        features['sma_50'] = df['Close'].rolling(window=50).mean()
        features['sma_200'] = df['Close'].rolling(window=200).mean()
        
        # Price position relative to moving averages
        features['price_to_sma20'] = df['Close'] / features['sma_20']
        features['price_to_sma50'] = df['Close'] / features['sma_50']
        
        # Volatility
        features['volatility_20'] = df['Close'].rolling(window=20).std() / df['Close'].rolling(window=20).mean()
        
        # RSI (Relative Strength Index)
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        features['rsi'] = 100 - (100 / (1 + rs))
        
        # MACD
        ema12 = df['Close'].ewm(span=12).mean()
        ema26 = df['Close'].ewm(span=26).mean()
        features['macd'] = ema12 - ema26
        features['macd_signal'] = features['macd'].ewm(span=9).mean()
        features['macd_diff'] = features['macd'] - features['macd_signal']
        
        # Bollinger Bands
        sma = df['Close'].rolling(window=20).mean()
        std = df['Close'].rolling(window=20).std()
        features['bb_upper'] = sma + (std * 2)
        features['bb_lower'] = sma - (std * 2)
        features['bb_position'] = (df['Close'] - features['bb_lower']) / (features['bb_upper'] - features['bb_lower'])
        
        # Volume indicators
        features['volume_ma_ratio'] = df['Volume'] / df['Volume'].rolling(window=20).mean()
        
        # Momentum
        features['momentum_5'] = df['Close'] - df['Close'].shift(5)
        features['momentum_20'] = df['Close'] - df['Close'].shift(20)
        
        return features
    
    @staticmethod
    def create_training_target(df, lookahead_days=30, threshold=0.05):
        """
        Create target variable: 1 if stock returns > threshold in next lookahead_days, 0 otherwise
        This defines what we consider a "good buy"
        """
        future_returns = df['Close'].shift(-lookahead_days) / df['Close'] - 1
        target = (future_returns > threshold).astype(int)
        return target, future_returns

class StockAnalysisBot:
    """Main bot that orchestrates data fetching, feature engineering, and ML"""
    
    def __init__(self):
        self.fetcher = StockDataFetcher()
        self.engineer = FeatureEngineer()
        self.model = None
        self.scaler = StandardScaler()
        self.feature_cols = None
        self.model_path = 'stock_model.pkl'
        self.scaler_path = 'scaler.pkl'
    
    def train_model(self, tickers=None, lookback='2y'):
        """Train ML model on historical data"""
        logger.info("Starting model training...")
        
        if tickers is None:
            tickers = self.fetcher.get_sp500_tickers()
        
        all_features = []
        all_targets = []
        all_tickers = []
        
        for ticker in tickers:
            logger.info(f"Processing {ticker} for training...")
            
            # Get price data
            price_data = self.fetcher.fetch_stock_data(ticker, period=lookback)
            if price_data is None or len(price_data) < 100:
                continue
            
            # Calculate features
            features = self.engineer.calculate_technical_features(price_data)
            target, future_returns = self.engineer.create_training_target(price_data)
            
            # Drop rows with NaN
            valid_idx = ~(features.isna().any(axis=1) | target.isna())
            features = features[valid_idx]
            target = target[valid_idx]
            
            if len(features) > 30:
                all_features.append(features)
                all_targets.append(target)
                all_tickers.extend([ticker] * len(features))
        
        # Combine all data
        X = pd.concat(all_features, ignore_index=False)
        y = pd.concat(all_targets, ignore_index=False)
        
        # Remove duplicates in index
        X = X[~X.index.duplicated(keep='first')]
        y = y[~y.index.duplicated(keep='first')]
        
        logger.info(f"Training set size: {len(X)} samples")
        logger.info(f"Class distribution: {y.value_counts().to_dict()}")
        
        # Store feature columns
        self.feature_cols = X.columns.tolist()
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Train model
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y, test_size=0.2, random_state=42, stratify=y
        )
        
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=15,
            min_samples_split=10,
            min_samples_leaf=5,
            random_state=42,
            n_jobs=-1,
            class_weight='balanced'
        )
        
        self.model.fit(X_train, y_train)
        
        # Evaluate
        train_score = self.model.score(X_train, y_train)
        test_score = self.model.score(X_test, y_test)
        logger.info(f"Model training complete. Train accuracy: {train_score:.3f}, Test accuracy: {test_score:.3f}")
        
        # Save model
        self.save_model()
        
        return test_score
    
    def save_model(self):
        """Persist model to disk"""
        with open(self.model_path, 'wb') as f:
            pickle.dump(self.model, f)
        with open(self.scaler_path, 'wb') as f:
            pickle.dump(self.scaler, f)
        logger.info("Model saved")
    
    def load_model(self):
        """Load saved model"""
        if os.path.exists(self.model_path):
            with open(self.model_path, 'rb') as f:
                self.model = pickle.load(f)
            with open(self.scaler_path, 'rb') as f:
                self.scaler = pickle.load(f)
            logger.info("Model loaded")
            return True
        return False
    
    def score_stock(self, ticker):
        """Score a single stock as buy opportunity (0-100)"""
        try:
            # Get current data
            price_data = self.fetcher.fetch_stock_data(ticker, period='1y')
            if price_data is None or len(price_data) < 50:
                return None
            
            # Get fundamentals
            fundamentals = self.fetcher.fetch_stock_info(ticker)
            if fundamentals is None:
                return None
            
            # Calculate features
            features = self.engineer.calculate_technical_features(price_data)
            
            # Get latest row
            latest_features = features.iloc[-1:]
            
            if latest_features.isna().any().any():
                return None
            
            # Scale and predict
            X_scaled = self.scaler.transform(latest_features[self.feature_cols])
            
            # Get probability of being a "good buy"
            prob = self.model.predict_proba(X_scaled)[0][1]
            
            # Combine with fundamental score
            fundamental_score = self._calculate_fundamental_score(fundamentals)
            
            # Weighted average: 60% ML model, 40% fundamentals
            combined_score = (prob * 0.6) + (fundamental_score * 0.4)
            
            return {
                'ticker': ticker,
                'ml_score': prob,
                'fundamental_score': fundamental_score,
                'combined_score': combined_score,
                'current_price': fundamentals['current_price'],
                'pe_ratio': fundamentals['pe_ratio'],
                'pb_ratio': fundamentals['pb_ratio'],
                'rsi': features['rsi'].iloc[-1],
                'macd_diff': features['macd_diff'].iloc[-1],
                'price_to_sma50': features['price_to_sma50'].iloc[-1],
                'volatility': features['volatility_20'].iloc[-1],
                'timestamp': datetime.now()
            }
        except Exception as e:
            logger.debug(f"Error scoring {ticker}: {e}")
            return None
    
    def _calculate_fundamental_score(self, fundamentals):
        """Score fundamentals 0-1"""
        score = 0.5  # Start at neutral
        
        pe = fundamentals.get('pe_ratio', np.nan)
        if not np.isnan(pe) and pe > 0:
            # Lower PE is better, but not too low. Ideal range: 10-20
            if pe < 10:
                score += 0.1
            elif pe < 20:
                score += 0.2
            elif pe < 30:
                score += 0.1
            # else: no bonus
        
        pb = fundamentals.get('pb_ratio', np.nan)
        if not np.isnan(pb) and pb > 0:
            # Lower PB is better, ideal < 3
            if pb < 1:
                score += 0.1
            elif pb < 3:
                score += 0.05
        
        roe = fundamentals.get('roe', np.nan)
        if not np.isnan(roe) and roe > 0.15:
            score += 0.1
        
        debt_to_equity = fundamentals.get('debt_to_equity', np.nan)
        if not np.isnan(debt_to_equity) and debt_to_equity < 2:
            score += 0.1
        
        return min(score, 1.0)
    
    def screen_market(self, tickers=None, top_n=20):
        """Screen entire market for buy opportunities"""
        logger.info("Starting market-wide screening...")
        
        if tickers is None:
            tickers = self.fetcher.get_sp500_tickers()
        
        results = []
        for i, ticker in enumerate(tickers):
            if i % 10 == 0:
                logger.info(f"Screened {i}/{len(tickers)} stocks...")
            
            score = self.score_stock(ticker)
            if score is not None:
                results.append(score)
        
        # Sort by combined score
        results_df = pd.DataFrame(results)
        results_df = results_df.sort_values('combined_score', ascending=False)
        
        logger.info(f"Screening complete. Found {len(results_df)} scoreable stocks")
        
        return results_df.head(top_n)
    
    def generate_report(self, results_df):
        """Generate text report of findings"""
        report = []
        report.append("=" * 80)
        report.append("STOCK ANALYSIS BOT - BUY OPPORTUNITY REPORT")
        report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("=" * 80)
        report.append("")
        
        report.append("TOP BUY OPPORTUNITIES (Score: 0-1, higher is better)")
        report.append("-" * 80)
        
        for idx, row in results_df.iterrows():
            report.append(f"\n{row['ticker']} | Score: {row['combined_score']:.3f}")
            report.append(f"  ML Score: {row['ml_score']:.3f} | Fundamental: {row['fundamental_score']:.3f}")
            report.append(f"  Current Price: ${row['current_price']:.2f}")
            if not np.isnan(row['pe_ratio']):
                report.append(f"  P/E Ratio: {row['pe_ratio']:.2f}")
            report.append(f"  RSI: {row['rsi']:.1f} | MACD Signal: {row['macd_diff']:.4f}")
            report.append(f"  Price to 50-day MA: {row['price_to_sma50']:.3f}")
        
        report.append("\n" + "=" * 80)
        report.append("Disclaimer: This is for educational purposes only. Not investment advice.")
        report.append("=" * 80)
        
        return "\n".join(report)


def main():
    """Main execution"""
    bot = StockAnalysisBot()
    
    # Check if model exists; if not, train it
    if not bot.load_model():
        logger.info("No existing model found. Training new model...")
        bot.train_model()
    
    # Screen the market
    top_picks = bot.screen_market(top_n=20)
    
    # Generate and save report
    report = bot.generate_report(top_picks)
    print(report)
    
    # Save results to CSV
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    csv_file = f'stock_picks_{timestamp}.csv'
    top_picks.to_csv(csv_file, index=False)
    logger.info(f"Results saved to {csv_file}")
    
    # Save report to text file
    report_file = f'report_{timestamp}.txt'
    with open(report_file, 'w') as f:
        f.write(report)
    logger.info(f"Report saved to {report_file}")


if __name__ == '__main__':
    main()
