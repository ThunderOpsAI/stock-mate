# Stock Analysis Bot - Setup & Usage Guide

## Overview
This bot performs market-wide screening to identify "good buy" opportunities using:
- **Technical Analysis**: Moving averages, RSI, MACD, Bollinger Bands, volume indicators
- **Fundamental Analysis**: P/E ratio, P/B ratio, ROE, debt levels
- **ML Model**: Random Forest classifier trained on 2 years of historical data to predict 30-day returns
- **Free Data**: Yahoo Finance (yfinance) - no API keys needed

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the Bot
```bash
python stock_bot_main.py
```

On first run:
- Will fetch 2 years of S&P 500 data (~100 stocks to start)
- Train a Random Forest model on technical & fundamental features
- Screen the market for top 20 buy opportunities
- Generate CSV and text report

Subsequent runs:
- Uses cached model
- Completes in 5-10 minutes for ~500 stocks

### 3. Review Results
- `report_YYYYMMDD_HHMMSS.txt` - Human-readable report
- `stock_picks_YYYYMMDD_HHMMSS.csv` - Results in spreadsheet format
- `stock_bot.log` - Detailed logs of what happened

## How It Works

### Training Phase (First Run)
1. Fetches 2 years of historical data for 100 S&P 500 stocks
2. Calculates 20+ technical indicators for each stock
3. Extracts fundamental metrics (P/E, P/B, ROE, etc.)
4. Creates training target: "Did this stock return >5% in the next 30 days?"
5. Trains Random Forest to predict which stocks will be good 30-day buys
6. Saves model + scaler for future use

### Scoring Phase (Every Run)
For each stock in the universe:
1. Fetches latest price & volume data
2. Calculates technical indicators from recent prices
3. Fetches current fundamentals
4. ML model predicts probability it's a good buy (0-1)
5. Fundamental score assigned based on P/E, P/B, ROE, debt
6. **Combined Score = 60% ML + 40% Fundamentals**
7. Sorts by combined score, reports top 20

### ML Model Details
- **Algorithm**: Random Forest (100 trees)
- **Features**: 25+ technical & fundamental indicators
- **Target**: 30-day forward returns > 5%
- **Training Data**: 2 years of OHLCV + fundamentals for 100 stocks
- **Validation**: 80/20 train/test split, typically 65-75% accuracy

## Customization

### Change the Stock Universe
Edit the `get_sp500_tickers()` method in `StockDataFetcher` class:
- Currently: S&P 500 (top 100)
- Could be: Nasdaq 100, Russell 2000, custom list

```python
# Example: Use custom tickers
tickers = ['AAPL', 'MSFT', 'GOOGL', 'NVDA', ...]
results = bot.screen_market(tickers=tickers, top_n=20)
```

### Adjust ML Model Target
In `create_training_target()`, change the threshold (currently 5%):
```python
target = (future_returns > 0.10).astype(int)  # Now: 10% in 30 days
```

### Change Screening Output
In `screen_market()`, adjust `top_n`:
```python
results = bot.screen_market(top_n=50)  # Top 50 instead of 20
```

### Adjust Feature Weights
In `score_stock()`, modify the weighting:
```python
# Currently: 60% ML, 40% fundamentals
combined_score = (prob * 0.8) + (fundamental_score * 0.2)  # More ML-driven
```

### Add More Indicators
In `FeatureEngineer.calculate_technical_features()`, add indicators like:
- Stochastic Oscillator
- ATR (Average True Range)
- Volume Profile
- On-Balance Volume (OBV)

## Automation (Hands-Off)

### On Mac/Linux: Use Cron
```bash
# Edit crontab
crontab -e

# Add this line to run daily at 5 AM (before market open)
0 5 * * 1-5 cd /path/to/stock_bot && python stock_bot_main.py

# Check cron logs
log stream --predicate 'process == "cron"' --level debug
```

### On Windows: Use Task Scheduler
1. Open Task Scheduler
2. Create Basic Task
3. Set trigger: Daily at 5 AM
4. Set action: Run program `python.exe`, add arguments: `C:\path\to\stock_bot_main.py`

### Getting Reports Emailed
Add this to `main()` at the end:

```python
import smtplib
from email.mime.text import MIMEText

def send_email_report(report_text):
    sender = 'your_email@gmail.com'
    recipient = 'your_email@gmail.com'
    password = 'your_app_password'  # Use Gmail app password for security
    
    msg = MIMEText(report_text)
    msg['Subject'] = 'Stock Bot - Daily Buy Opportunities'
    msg['From'] = sender
    msg['To'] = recipient
    
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
        server.login(sender, password)
        server.sendmail(sender, recipient, msg.as_string())

# In main(), after generating report:
send_email_report(report)
```

## Performance Tips

### For Faster Initial Training
- Reduce number of stocks: `tickers = bot.fetcher.get_sp500_tickers()[:50]`
- Use shorter lookback: `bot.train_model(lookback='1y')`

### For More Stocks
```python
# Include more S&P 500
tickers = bot.fetcher.get_sp500_tickers()  # Remove the [:100] slice
# Or expand to custom list of 500+ stocks
results = bot.screen_market(tickers=my_500_tickers, top_n=30)
```

### Caching
The bot caches downloaded data but will always refetch fundamentals. To speed up:
- First run: ~20-30 min (trains model + scores ~100 stocks)
- Subsequent runs: ~5-10 min (uses cached model, scores ~100 stocks)

## Interpreting Results

### What Each Score Means
- **Combined Score 0.7-1.0**: Strong buy signal (top candidates)
- **Combined Score 0.5-0.7**: Moderate buy signal
- **Combined Score < 0.5**: Weak signal or avoid

### Key Indicators to Watch
- **RSI**: 20-30 = oversold (good buy), 70+ = overbought (sell)
- **MACD Diff**: Positive = bullish, negative = bearish
- **Price to SMA50**: <0.95 = undervalued, >1.05 = overvalued
- **P/E Ratio**: Lower is better if fundamentals are solid
- **Volatility**: High = higher risk, lower = more stable

## Limitations & Disclaimers

1. **Not Investment Advice**: This is educational. Do your own due diligence.
2. **Past Performance ≠ Future Results**: ML model trained on historical data
3. **Market Gaps**: Data gaps, delisted stocks, or API limits can affect results
4. **No Sentiment**: Model doesn't include social sentiment, news, or market conditions
5. **Survivor Bias**: Only analyzes stocks that currently exist in data
6. **Parameter Risk**: 30-day horizon & 5% threshold are arbitrary

## Enhancing the Bot

### Medium Complexity Additions
- Add sentiment analysis (news headlines)
- Include more fundamental metrics (cash flow, dividend history)
- Add sector rotation logic
- Backtest on rolling windows to validate accuracy

### Advanced Features
- Integration with Alpaca or Interactive Brokers API to auto-trade
- Dashboard with Streamlit or Dash
- Portfolio optimization (which stocks to own together)
- Risk modeling (Value at Risk, Sharpe ratio)
- Discord/Slack notifications
- Database storage of all screens (PostgreSQL, SQLite)

## Troubleshooting

**Q: "Error: Not enough data for ticker X"**
- Some stocks have insufficient history. Bot skips them. Normal.

**Q: "Model accuracy seems low"**
- Try retraining with more stocks or longer lookback period
- Adjust the target threshold in `create_training_target()`

**Q: "Script is very slow"**
- Reduce number of stocks in initial training
- Run screening in batches
- Use `n_jobs=-1` in RandomForest (already enabled)

**Q: "Results don't match my research"**
- Bot uses mechanical signals. Cross-reference with fundamental analysis.
- The ML model is probabilistic, not deterministic.

## Next Steps

1. ✅ Install and run the bot once
2. ✅ Review the reports and compare to stocks you know
3. ✅ Backtest results (check if top picks actually did well)
4. ✅ Set up cron job to run daily
5. ✅ Expand to more stocks (Russell 3000 instead of S&P 500)
6. ✅ Add your own custom filters (e.g., min market cap, sector)
7. ✅ Integrate with a broker API if you want to auto-trade

## Questions?

Common customizations:
- Different stock universe (Nasdaq, international, crypto)
- Different target metric (6-month returns instead of 30-day)
- Include options data
- Multi-factor analysis
- Portfolio construction

Feel free to modify and experiment!
